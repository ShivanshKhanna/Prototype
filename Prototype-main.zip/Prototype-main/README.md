# Prototype
Code surrounding the Prototype
Optical character recognition is important as it is the main process of the entire system. While using tesseract, opencv and the camera, 
I have created an efficient but improvable system for OCR
I used different filters which are important for recognising specific details, of which the important filters of adaptive threshold and contouring is useful
for identifying license plates. 

RFID:
RFID communication is important for establishing the payment system, where I only worked with working the RFID module through reading and writing. 
Raspberry Pi reduces the length of the RFID code by utilising functions already introduced in python

Arduino to Raspberry Pi communication:
Opening the micro-servo boom gate given payment has been recieved of the time of the camera is important for the carpark, which is why I utilised 
tutorial arduino to rpi communication to send signals between each other, of which opens and closes the boom gate
